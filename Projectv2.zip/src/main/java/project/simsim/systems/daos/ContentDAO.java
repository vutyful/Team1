package project.simsim.systems.daos;

import project.simsim.systems.domains.ContentVO;

public interface ContentDAO {
	public void saveContent(ContentVO vo);
}
