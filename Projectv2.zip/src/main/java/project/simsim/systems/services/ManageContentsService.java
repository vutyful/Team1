package project.simsim.systems.services;

import project.simsim.systems.domains.ContentVO;

public interface ManageContentsService {
	void saveContent(ContentVO vo); 
}
